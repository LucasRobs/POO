class Pagamento{
    
}
class Boleto extends Pagamento{

}
class Credito extends Pagamento{
    
}