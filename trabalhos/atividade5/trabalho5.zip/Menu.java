class Menu{
    public void AdicionarPessoa(){

    }
    public Boolean Criar_Cadastro(){
        return true;
    }
    public void Adicionar_Maquina(){
        
    }
    public void Listar_Inadiplentes(){

    }
    public void Adicionar_Filial(){

    }
}