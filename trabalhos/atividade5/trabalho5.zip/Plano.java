class Plano{
    
    public double valor(){
        return 0;
    }
}
class PlanoA extends Plano{

}
class PlanoB extends Plano{

}
class PlanoC extends Plano{
    
}