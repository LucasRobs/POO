class Funcionario extends Pessoa{
    String login;
    int senha;
}
class Faxineira extends Funcionario{

}
class Atendente_Caixa extends Funcionario{
    
}
class Instrutor extends Funcionario{
    
}
class Gerente extends Funcionario{
    
}