import java.util.ArrayList;

class Academia{
    private Endereco end;
    private ArrayList<Maquina> maquinas = new ArrayList<Maquina>();
}