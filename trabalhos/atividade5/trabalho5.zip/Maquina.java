class Maquina{
    private String nome;
    private int id;
}