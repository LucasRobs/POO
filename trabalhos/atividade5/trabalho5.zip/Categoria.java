class CategoriaA extends Maquina{

}
class CategoriaB extends Maquina{

}
class CategoriaC extends Maquina{

}
class CategoriaD extends Maquina{

}