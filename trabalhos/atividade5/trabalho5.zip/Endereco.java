class Endereco{
    private String rua;
    private String bairro;
    private int numero;
}