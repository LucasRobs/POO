class Cadastro_Cliente{
    private int mes_ultimo_pagamento;
    private Cliente cliente;
    public double valor(){
        return 0;
    }
}