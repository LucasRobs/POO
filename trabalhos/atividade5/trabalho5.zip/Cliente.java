class Cliente extends Pessoa{
    private int id;
}