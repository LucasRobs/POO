class Maquinas{
    private String nome;

    public String getNome() {
        return this.nome;
    }
}