class Plano_basico extends Planos{

}