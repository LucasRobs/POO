class Auxiliares extends Funcionario{
    
}