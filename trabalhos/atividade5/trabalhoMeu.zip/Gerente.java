class Gerente extends Funcionario{
    
}