class Boleto extends Pagamento{
    @Override
    public int getValor() {
        return 3;
    }
}