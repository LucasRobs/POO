class Cartao extends Pagamento{
    
}