class Caixa extends Funcionario{
    
}