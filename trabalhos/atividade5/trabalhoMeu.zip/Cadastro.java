class Cadastro{
    public Cliente cadastrarCliente() {
        Cliente x = new Cliente();
        System.out.println("Nome do cliente");
        //ler
        //x.setNome(y);
        System.out.println("CPF");
        //ler
        //x.setCpf(y);
        System.out.println("Plano");
        //ler
        //x.setPlano = escolherPlano(y);
        System.out.println("Forma de Pagamento");
        //ler
        //x.setPagamento = TipoDePagamento(y);
        return x;
    }
    public Funcionario cadastrarFunionario() {
        Funcionario x = new Funcionario();
        System.out.println("Nome do cliente");
        //ler
        //x.setNome(y);
        System.out.println("CPF");
        //ler
        //x.setCpf(y);
        System.out.println("Cargo");
        //ler
        //x.cargo = setCargo(y);
        return x;
    }
}