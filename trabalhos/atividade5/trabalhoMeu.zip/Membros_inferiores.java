class Menbro_inferiores extends Maquinas{
    
}