class Ginastica extends Maquinas{
    
}