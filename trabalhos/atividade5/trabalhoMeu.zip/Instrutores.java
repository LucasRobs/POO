class Instutores extends Funcionario{
}