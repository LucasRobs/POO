class Plano_medio extends Planos{
    @Override
    public int getMensalidade() {
        return getMensalidade() + 30;
    }
}