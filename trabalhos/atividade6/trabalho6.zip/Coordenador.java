class Coordenador extends Administrador{

}
