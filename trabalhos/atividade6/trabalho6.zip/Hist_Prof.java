import java.util.ArrayList;
class Hist_Prof{
  private ArrayList<Turma> turma_atual;
  private ArrayList<Turma> turmas_antigas;  
}
