class Avaliacao{
  private double nota;
  private String data;
  private Horario inicio;
}
