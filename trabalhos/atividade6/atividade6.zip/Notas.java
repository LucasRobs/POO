import java.util.ArrayList;
class Notas{
  ArrayList<Avaliacao> avaliacoes;
}
