class Reitor extends Administrador{
    public Reitor(String in_nome, String in_senha) {
        this.nome = in_nome;
        this.senha = in_senha;
    }
}
