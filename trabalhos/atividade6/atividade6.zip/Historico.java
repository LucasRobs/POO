import java.util.ArrayList;
class Historico{
  private int frequencia;
  private ArrayList<Notas> notas;
}
